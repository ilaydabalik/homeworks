package edu.sabanciuniv.test;

import edu.sabanciuniv.model.*;
import edu.sabanciuniv.utility.EntityManagerUtils;
import jakarta.persistence.EntityManager;

public class testClass {
    public static void main(String[] args) {

        saveTestData();

    }

    public testClass() {
    }

    private static void saveTestData() {

        Student student1 = new Student("Ilayda Balik","23.09.1994","Kadikoy","Female");
        Student student2 = new Student("Ayşe Balik","24.10.1995","Uskudar","Female");
        Student student3 = new Student("Fatma Balik","25.11.1996","Altunizade","Female");
        Student student4 = new Student("Ali Balik","26.12.1997","Sariyer","Male");
        Student student5 = new Student("Ahmet Balik","27.01.1998","Besiktas","Male");

        Courses courses1 = new Courses("Math",12345,90.0);
        Courses courses2 = new Courses("Physic",213244,100.0);
        Courses courses3 = new Courses("Biology",4534535,98.9);
        Courses courses4 = new Courses("Programming",654646,100.0);
        Courses courses5 = new Courses("Art",34523,90.7);

        Instructors instructors1 = new PermenantInstructor("ayse","kadikoy","123123",20000.0);
        Instructors instructors2 = new PermenantInstructor("ali","uskudar","6786768",15000.0);
        Instructors instructors3 = new VisitingResearcher("mehmet","altunizade","45646456",100.0);
        Instructors instructors4 = new VisitingResearcher("ahmet","sariyer","674545",120.0);
        Instructors instructors5 = new VisitingResearcher("oya","nisantasi","64563563",150.0);
        
        instructors1.setCourses(courses1);
        instructors2.setCourses(courses2);
        instructors3.setCourses(courses3);
        instructors4.setCourses(courses4);
        instructors5.setCourses(courses5);

        courses1.getStudentList().add(student1);
        courses2.getStudentList().add(student2);
        courses3.getStudentList().add(student3);
        courses4.getStudentList().add(student4);
        courses5.getStudentList().add(student5);


        EntityManager entityManager = EntityManagerUtils.getEntityManager("mysqlPU");
        try{
        entityManager.getTransaction().begin();
        entityManager.persist(courses1);
        entityManager.persist(courses2);
        entityManager.persist(courses3);
        entityManager.persist(courses4);
        entityManager.persist(courses5);

        entityManager.persist(student1);
        entityManager.persist(student2);
        entityManager.persist(student3);
        entityManager.persist(student4);
        entityManager.persist(student5);

        entityManager.persist(instructors1);
        entityManager.persist(instructors2);
        entityManager.persist(instructors3);
        entityManager.persist(instructors4);
        entityManager.persist(instructors5);

        entityManager.getTransaction().commit();
        System.out.println("All data persisted..");

        }catch (Exception e){
            entityManager.getTransaction().rollback();
        }finally {
            EntityManagerUtils.closeEntityManager(entityManager);

        }
    }


}
