package edu.sabanciuniv.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class PermenantInstructor extends Instructors {

    private double fixedSalary;

    public PermenantInstructor(String name, String address, String phoneNumber, double fixedSalary) {
        super(name, address, phoneNumber);
        this.fixedSalary = fixedSalary;
    }

    public PermenantInstructor(double fixedSalary) {
        this.fixedSalary = fixedSalary;
    }

    public PermenantInstructor(){}

    public double getFixedSalary() {
        return fixedSalary;
    }

    public void setFixedSalary(double fixedSalary) {
        this.fixedSalary = fixedSalary;
    }

    @Override
    public String toString() {
        return "PermenantInstructor{" +
                "fixedSalary=" + fixedSalary +
                "} " + super.toString();
    }


}
