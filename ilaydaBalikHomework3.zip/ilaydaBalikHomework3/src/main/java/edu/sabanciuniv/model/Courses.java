package edu.sabanciuniv.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
@Entity
public class Courses {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String courseName;
    private long courseCode;
    private double creditScore;

    @OneToMany(mappedBy = "Courses")
    //Bir kursun hiç öğrencisi olmayabilir ya da bir sürü öğrencisi olabilir
    private List<Student> studentList = new ArrayList<>();

    @OneToMany(mappedBy = "Instructors")
    private List<Instructors> instructorsList = new ArrayList<>();

    public Courses(String courseName, long courseCode, double creditScore) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.creditScore = creditScore;
    }

    public Courses() {
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public long getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(long courseCode) {
        this.courseCode = courseCode;
    }

    public double getCreditScore() {
        return creditScore;
    }

    public void setCreditScore(double creditScore) {
        this.creditScore = creditScore;
    }

    public List<Student> getStudentList() {
        return studentList;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Courses courses = (Courses) o;

        if (courseCode != courses.courseCode) return false;
        if (Double.compare(courses.creditScore, creditScore) != 0) return false;
        return Objects.equals(courseName, courses.courseName);
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = courseName != null ? courseName.hashCode() : 0;
        result = 31 * result + (int) (courseCode ^ (courseCode >>> 32));
        temp = Double.doubleToLongBits(creditScore);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public String toString() {
        return "Courses{" +
                "courseName='" + courseName + '\'' +
                ", courseCode=" + courseCode +
                ", creditScore=" + creditScore +
                '}';
    }


}
